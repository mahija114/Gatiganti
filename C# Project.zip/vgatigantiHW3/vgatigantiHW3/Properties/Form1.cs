﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace vgatigantiHW3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

       
        private void processSaleButton_Click(object sender, EventArgs e)
        {
            Transaction atransaction = new Transaction();
            atransaction.TransactionID = transactionIDtextBox.Text;
            atransaction.SoftwareName = sNamelistBox.SelectedItem.ToString();
            atransaction.NumberOfLicenses = int.Parse(licensesRequiredtextBox.Text);
            atransaction.DateofService = setupDateTimePicker.Value;
            atransaction.SetupOption = addSetUpradioButton.Checked;
            atransaction.CustomerName = customerNametextBox.Text;
            if (addSetUpradioButton.Checked == true)
            {
                atransaction.SetupOption = true;
                setupDateTimePicker.Visible = true;
            }
            displaylistBox.Items.Add(atransaction.ToString());
        }
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            setupDateTimePicker.Visible = true;
        }


    }
}
