﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace vgatigantiHW3
{
    class Transaction
    {
        internal const int SALES_MANAGEMENT = 2000;
        internal const int BACKUP_MANAGER = 800;
        internal const int PAYROLL_SOLUTIONS = 4500;
        internal const int EASYMEETING = 1000;

        public string CustomerName{ get; set; }
        public string TransactionID { get; set; }
        public string SoftwareName { get; set; }
        public int NumberOfLicenses { get; set; }
        public bool SetupOption { get; set; }
        public DateTime DateofService { get; set; }

        public double ServiceCharge
        {
            get
            {
                return 500 * NumberOfLicenses;
            }
            set
            {


            }
        }

        public double Charge(string SoftwareName)
        {
            double charge = 0;

            if (SoftwareName.Equals("SalesManagement"))
            {
                charge = NumberOfLicenses * SALES_MANAGEMENT;
            }
            else if (SoftwareName.Equals("PayRollSolutions"))
            {
                charge = NumberOfLicenses * PAYROLL_SOLUTIONS;
            }
            else if (SoftwareName.Equals("BackUpManager"))
            {
                charge = NumberOfLicenses * BACKUP_MANAGER;
            }
            else
            {
                charge = NumberOfLicenses * EASYMEETING;
            }
            return charge;
        }
        public double CalculateTotalCharge()
        {

            
            double setupfee = 0;
           
            if (SetupOption == true)
            {

                setupfee = ServiceCharge;
            }

            return Charge(SoftwareName) + setupfee;
        }

        public override string ToString()
        {
            return "Customer Name: " + CustomerName + "Software Name: " + SoftwareName + " Setup Option: " + SetupOption + " Charge " + Charge(SoftwareName) + " Total Charge: " + CalculateTotalCharge() + "Date: " + DateofService;
        }

    }
}

