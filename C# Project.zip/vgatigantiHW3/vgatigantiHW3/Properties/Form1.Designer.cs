﻿namespace vgatigantiHW3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.transactionIDtextBox = new System.Windows.Forms.TextBox();
            this.customerNametextBox = new System.Windows.Forms.TextBox();
            this.licensesRequiredtextBox = new System.Windows.Forms.TextBox();
            this.sNamelistBox = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.addSetUpradioButton = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.setupDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.displaylistBox = new System.Windows.Forms.ListBox();
            this.processSaleButton = new System.Windows.Forms.Button();
            this.cancelSaleButton = new System.Windows.Forms.Button();
            this.viewSalesReportButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // transactionIDtextBox
            // 
            this.transactionIDtextBox.Location = new System.Drawing.Point(119, 33);
            this.transactionIDtextBox.Name = "transactionIDtextBox";
            this.transactionIDtextBox.Size = new System.Drawing.Size(100, 20);
            this.transactionIDtextBox.TabIndex = 0;
            // 
            // customerNametextBox
            // 
            this.customerNametextBox.Location = new System.Drawing.Point(119, 90);
            this.customerNametextBox.Name = "customerNametextBox";
            this.customerNametextBox.Size = new System.Drawing.Size(100, 20);
            this.customerNametextBox.TabIndex = 1;
            // 
            // licensesRequiredtextBox
            // 
            this.licensesRequiredtextBox.Location = new System.Drawing.Point(119, 149);
            this.licensesRequiredtextBox.Name = "licensesRequiredtextBox";
            this.licensesRequiredtextBox.Size = new System.Drawing.Size(100, 20);
            this.licensesRequiredtextBox.TabIndex = 2;
            // 
            // sNamelistBox
            // 
            this.sNamelistBox.FormattingEnabled = true;
            this.sNamelistBox.Items.AddRange(new object[] {
            "SalesManagement",
            "BackUpManager",
            "PayRollSolutions",
            "EasyMeeting"});
            this.sNamelistBox.Location = new System.Drawing.Point(244, 36);
            this.sNamelistBox.Name = "sNamelistBox";
            this.sNamelistBox.Size = new System.Drawing.Size(120, 95);
            this.sNamelistBox.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Transaction ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 93);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Customer Name:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(19, 156);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(98, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Licenses Required:";
            // 
            // addSetUpradioButton
            // 
            this.addSetUpradioButton.AutoSize = true;
            this.addSetUpradioButton.Location = new System.Drawing.Point(406, 39);
            this.addSetUpradioButton.Name = "addSetUpradioButton";
            this.addSetUpradioButton.Size = new System.Drawing.Size(74, 17);
            this.addSetUpradioButton.TabIndex = 7;
            this.addSetUpradioButton.TabStop = true;
            this.addSetUpradioButton.Text = "AddSetUp";
            this.addSetUpradioButton.UseVisualStyleBackColor = true;
            this.addSetUpradioButton.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(406, 89);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(91, 17);
            this.radioButton2.TabIndex = 8;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "DeclineSetUp";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // setupDateTimePicker
            // 
            this.setupDateTimePicker.Location = new System.Drawing.Point(519, 35);
            this.setupDateTimePicker.Name = "setupDateTimePicker";
            this.setupDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.setupDateTimePicker.TabIndex = 9;
            // 
            // displaylistBox
            // 
            this.displaylistBox.FormattingEnabled = true;
            this.displaylistBox.Location = new System.Drawing.Point(41, 224);
            this.displaylistBox.Name = "displaylistBox";
            this.displaylistBox.Size = new System.Drawing.Size(678, 134);
            this.displaylistBox.TabIndex = 10;
            // 
            // processSaleButton
            // 
            this.processSaleButton.AutoSize = true;
            this.processSaleButton.Location = new System.Drawing.Point(390, 135);
            this.processSaleButton.Name = "processSaleButton";
            this.processSaleButton.Size = new System.Drawing.Size(79, 23);
            this.processSaleButton.TabIndex = 11;
            this.processSaleButton.Text = "Process Sale";
            this.processSaleButton.UseVisualStyleBackColor = true;
            this.processSaleButton.Click += new System.EventHandler(this.processSaleButton_Click);
            // 
            // cancelSaleButton
            // 
            this.cancelSaleButton.Location = new System.Drawing.Point(536, 135);
            this.cancelSaleButton.Name = "cancelSaleButton";
            this.cancelSaleButton.Size = new System.Drawing.Size(75, 23);
            this.cancelSaleButton.TabIndex = 12;
            this.cancelSaleButton.Text = "Cancel Sale";
            this.cancelSaleButton.UseVisualStyleBackColor = true;
            // 
            // viewSalesReportButton
            // 
            this.viewSalesReportButton.AutoSize = true;
            this.viewSalesReportButton.Location = new System.Drawing.Point(470, 180);
            this.viewSalesReportButton.Name = "viewSalesReportButton";
            this.viewSalesReportButton.Size = new System.Drawing.Size(104, 23);
            this.viewSalesReportButton.TabIndex = 13;
            this.viewSalesReportButton.Text = "View Sales Report";
            this.viewSalesReportButton.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(731, 383);
            this.Controls.Add(this.viewSalesReportButton);
            this.Controls.Add(this.cancelSaleButton);
            this.Controls.Add(this.processSaleButton);
            this.Controls.Add(this.displaylistBox);
            this.Controls.Add(this.setupDateTimePicker);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.addSetUpradioButton);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.sNamelistBox);
            this.Controls.Add(this.licensesRequiredtextBox);
            this.Controls.Add(this.customerNametextBox);
            this.Controls.Add(this.transactionIDtextBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox transactionIDtextBox;
        private System.Windows.Forms.TextBox customerNametextBox;
        private System.Windows.Forms.TextBox licensesRequiredtextBox;
        private System.Windows.Forms.ListBox sNamelistBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RadioButton addSetUpradioButton;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.DateTimePicker setupDateTimePicker;
        private System.Windows.Forms.ListBox displaylistBox;
        private System.Windows.Forms.Button processSaleButton;
        private System.Windows.Forms.Button cancelSaleButton;
        private System.Windows.Forms.Button viewSalesReportButton;
    }
}

